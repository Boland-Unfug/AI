I had to do a different thing in order to get the autograder to work, now that python 3.6 is depriciated.
You can run the code and autograder if you activate the py3.6 conda environment, using conda activate py3.6
Please contact me if the code does not run, I passed all tests on my own computer and it is likely unintentional

Question q1
===========

*** PASS: test_cases\q1\addition1.test
***     add(a,b) returns the sum of a and b
*** PASS: test_cases\q1\addition2.test
***     add(a,b) returns the sum of a and b
*** PASS: test_cases\q1\addition3.test
***     add(a,b) returns the sum of a and b

### Question q1: 1/1 ###


Question q2
===========

*** PASS: test_cases\q2\food_price1.test
***     buyLotsOfFruit correctly computes the cost of the order
*** PASS: test_cases\q2\food_price2.test
***     buyLotsOfFruit correctly computes the cost of the order
*** PASS: test_cases\q2\food_price3.test
***     buyLotsOfFruit correctly computes the cost of the order

### Question q2: 1/1 ###


Question q3
===========

Welcome to shop1 fruit shop
Welcome to shop2 fruit shop
*** PASS: test_cases\q3\select_shop1.test
***     shopSmart(order, shops) selects the cheapest shop
Welcome to shop1 fruit shop
Welcome to shop2 fruit shop
*** PASS: test_cases\q3\select_shop2.test
***     shopSmart(order, shops) selects the cheapest shop
Welcome to shop1 fruit shop
Welcome to shop2 fruit shop
Welcome to shop3 fruit shop
*** PASS: test_cases\q3\select_shop3.test
***     shopSmart(order, shops) selects the cheapest shop

### Question q3: 1/1 ###


Finished at 12:56:03

Provisional grades
==================
Question q1: 1/1
Question q2: 1/1
Question q3: 1/1
------------------
Total: 3/3

Your grades are NOT yet registered.  To register your grades, make sure
to follow your instructor's guidelines to receive credit on your project.